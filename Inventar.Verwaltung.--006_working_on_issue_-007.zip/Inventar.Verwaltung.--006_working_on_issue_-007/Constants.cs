namespace Lumpix.Inventar.Verwaltung_
{
    public static class PreisMultiplikatoren
    {
        public const float Sonstiges = 2.5f;
        public const float Schadlingsbekaempfer = 2.0f;
        public const float Blumen = 3.0f;
        public const float Pflanzen = 2.5f;
        public const float FertigeArbeiten = 2.5f;
        public const float Default = 1f;
    }
    public static class Trenner
    {
        public const string trenner = "---#---";
    }
}