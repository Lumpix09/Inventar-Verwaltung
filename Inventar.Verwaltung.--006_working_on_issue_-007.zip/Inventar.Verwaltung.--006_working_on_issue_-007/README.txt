the icons are from https://www.svgrepo.com/
